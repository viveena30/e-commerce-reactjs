import React from 'react'
import './Btn.css'

const Btn = () => {
    return (
        <div className="btn-container">
            Join 
        </div>
    )
}

export default Btn
