export const cardOne = {
  title: "Jay Durga Provision Store ",
  city:'Ahemdabad',
  img: "images/1.jpg",
  alt: "product image",
};

export const cardTwo = {
  title: "Jay Durga Provision Store ",
  city:'Ahemdabad',
  img: "images/1.jpg",
  alt: "product image",
};

export const cardThree = {
  title: "Jay Durga Provision Store ",
  city:'Ahemdabad',
  img: "images/1.jpg",
  alt: "product image",
};

export const cardFour = {
  title: "Jay Durga Provision Store ",
  city:'Ahemdabad',
  img: "images/1.jpg",
  alt: "product image",
};
