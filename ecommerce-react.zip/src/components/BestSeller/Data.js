export const cardOne = {
  title:
    "Vintage Typewriter to post aw and webdev.",
  rating: "4.2",
  price: "$15",
  subtitle: "Eligible for Shipping To Mars or somewhere else",
  img: "images/1.jpg",
  alt: "product image",
};

export const cardTwo = {
  title:
    "Vintage Typewriter to post aw and webdev.",
  rating: "4.2",
  price: "$15",
  subtitle: "Eligible for Shipping To Mars or somewhere else",
  img: "images/1.jpg",
  alt: "product image",
};

export const cardThree = {
  title:
    "Vintage Typewriter to post aw and webdev.",
  rating: "4.2",
  price: "$15",
  subtitle: "Eligible for Shipping To Mars or somewhere else",
  img: "images/1.jpg",
  alt: "product image",
};

export const cardFour = {
  title:
    "Vintage Typewriter to post aw and webdev.",
  rating: "4.2",
  price: "$15",
  subtitle: "Eligible for Shipping To Mars or somewhere else",
  img: "images/1.jpg",
  alt: "product image",
};
