export const cardOne = {
  title:
    "Vintage Typewriter ",
  rating: "4.2",
  price: "$32",
  subtitle: "Eligible for Shipping To Mars or somewhere else",
  img: "images/watch.jpg",
  alt: "product image",
};

export const cardTwo = {
  title:
    "Vintage Typewriter ",
  rating: "4.2",
  price: "$32",
  subtitle: "Eligible for Shipping To Mars or somewhere else",
  img: "images/watch.jpg",
  alt: "product image",
};

export const cardThree = {
  title:
    "Vintage Typewriter ",
  rating: "4.2",
  price: "$32",
  subtitle: "Eligible for Shipping To Mars or somewhere else",
  img: "images/watch.jpg",
  alt: "product image",
};

export const cardFour = {
  title:
    "Vintage Typewriter ",
  rating: "4.2",
  price: "$32",
  subtitle: "Eligible for Shipping To Mars or somewhere else",
  img: "images/watch.jpg",
  alt: "product image",
};
