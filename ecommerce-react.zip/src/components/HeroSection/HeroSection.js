import React from 'react'
import HeroCarousel from '../HeroCarousel/HeroCarousel'

const HeroSection = () => {
    return (
        <>
            <HeroCarousel />
        </>
    )
}

export default HeroSection
